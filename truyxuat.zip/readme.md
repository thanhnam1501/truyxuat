# Smartcheck
Project is management about profifle's scientist.
#Framework
- Laravel
- Version: 5.6
# Server Requirements
- PHP >= 7.1.3
- OpenSSL PHP Extension
- PDO PHP Extension
- Mbstring PHP Extension
- Tokenizer PHP Extension
# Useage
```
git clone git@github.com:thanhnam1501/truyxuat.git
```
After that. Change .env.example to .env and run command in terminal
```
composer install
php artisan key:generate
npm install
npm run dev
```

