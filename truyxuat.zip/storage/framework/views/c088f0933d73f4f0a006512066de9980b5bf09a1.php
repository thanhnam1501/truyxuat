<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
	<?php for($i=0; $i <= $count; $i++): ?>	
	#qr-code<?php echo e($i); ?> {
		position: relative;
		top: -55px;
		left: -505px;
		width: 80px;
		height: 80px;
		border-radius: 4px;
	}
	#contentdiv<?php echo e($i); ?> {
		position: absolute;
		width: 400px;
		height: 200px;
	}
	#content<?php echo e($i); ?> {
		
		width: 400px;
		height: 200px;
	}

	<?php endfor; ?>
</style>
</head>
<body>
	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	
	<div id="contendiv<?php echo e($key); ?>" >
		<img id="content<?php echo e($key); ?>" src="<?php echo e(asset('image/aaaaa.jpg')); ?>" alt="">
		<img id="qr-code<?php echo e($key); ?>" style="margin-left: 20%; " src="data:image/png;base64, <?php echo base64_encode(QrCode::format('png')
		->size(200)
		->generate($value->qr_code)); ?> ">
	</div>
	
	
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html>