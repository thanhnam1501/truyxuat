<?php $__env->startSection('content'); ?>
 sadsad  adádsa sdadádad
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>