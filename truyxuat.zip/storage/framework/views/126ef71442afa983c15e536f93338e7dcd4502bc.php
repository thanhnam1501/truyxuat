<?php $__env->startSection('content'); ?>
<div class="logo">
	<h1 class="logo-caption">Đăng nhập</h1>
</div><!-- /.logo -->
<div class="controls">
	<form class="form-horizontal" method="POST" action="<?php echo e(route('profile.login.submit')); ?>">
		<?php echo e(csrf_field()); ?>

		<div class=form-group>
			<?php if(session('register-success')): ?>
			<div class="col-md-12">
				<div class="alert alert-success">
					<?php echo e(session('register-success')); ?>

				</div>
			</div>
			<?php endif; ?>

			<?php if(session('confirm-register-success')): ?>
			<div class="col-md-12">
				<div class="alert alert-success">
					<?php echo e(session('confirm-register-success')); ?>

				</div>
			</div>
			<?php endif; ?>

			<?php if(session('confirm-register-error')): ?>
			<div class="col-md-12">
				<div class="alert alert-danger">
					<?php echo e(session('confirm-register-error')); ?>

				</div>
			</div>
			<?php endif; ?>
		</div>
		<div class="form-group">
			<div class="col-md-12">
				<input type="text" class="form-control" placeholder="Email" id="email" name="email" value="<?php echo e(old("email")); ?>" />

				<?php if($errors->has('email')): ?>
				<span class="help-block">
					<div style="color:red;"><strong><?php echo e($errors->first('email')); ?></strong></div>
				</span>
				<?php endif; ?>
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-12">
				<input type="password" class="form-control" placeholder="Mật khẩu" id="password" name="password" value="<?php echo e(old("password")); ?>"/>

				<?php if($errors->has('password')): ?>
				<span class="help-block">
					<div style="color:red;"><strong><?php echo e($errors->first('password')); ?></strong></div>
				</span>
				<?php endif; ?>
			</div>
		</div>

		<div class="form-group">
			<div class="col-md-6 remember-checkbox">
				<input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

				<label class="form-check-label" for="remember">
					Ghi nhớ mật khẩu
				</label>
			</div>

			<div class="col-md-6">
				<button type="submit" class="btn login-btn btn-block">Đăng nhập</button>
			</div>

			<div class="col-md-12">
				<hr>
				<div class="col-md-6 btn-fogot custom-col-left">
					<a href="<?php echo e(route('profile.password.request')); ?>" class="btn-link">Quên mật khẩu?</a>
				</div>
				<div class="col-md-6 btn-register custom-col-right">
					<a href="<?php echo e(route('profile.register')); ?>" class="btn-link">Đăng ký tài khoản</a>
				</div>
			</div>
		</div>
	</form>
</div>
<div class="login-footer">
	<center>&copy; 2018 Zent Software</center>
</div>
</div><!-- /.controls -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>