<?php $__env->startSection('content'); ?>
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">						
	<div class="card mb-3">
		<div class="card-header">
			<h3><i class="fa fa-check-square-o"></i> Bước cập nhật</h3>
			
		</div>
		<?php if($errors->any()): ?>
		<div class="alert alert-danger"><?php echo e(implode('', $errors->all(':message'))); ?></div>
		<?php endif; ?>
		<br>
		<div class="clearfix"></div>
		<div class="card-body">
			<form action="<?php echo e(route('user.node.update')); ?>" method="POST">

				<div class="form-group">
					<label>Tên bước cập nhật</label>
					<input type="text" class="form-control" id="name" name="name" value="<?php echo e($data->name); ?>" placeholder="Họ và Tên" required>
					<input type="hidden" class="form-control" id="id" name="id" value="<?php echo e($data->id); ?>" placeholder="Họ và Tên" required>
				</div>

				<div class="form-group">
					<label>Mô tả</label>
					<textarea name="content" value="<?php echo e($data->content); ?>" class="form-control " id="editor1"><?php echo e($data->content); ?></textarea>
				</div> 
			<div class="s form-group has-feedback">

          <select class="form-control has-feedback-left" name="user_id1" id="user_id1" required>
            <option value="">Chọn nhân viên quản lý</option>
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php if($value->id == $data->user_id): ?> selected <?php endif; ?> value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
        </div>
        <?php echo e(csrf_field()); ?>


        <button type="submit" class="btn btn-primary">Cập nhật</button>
    </form>


</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>