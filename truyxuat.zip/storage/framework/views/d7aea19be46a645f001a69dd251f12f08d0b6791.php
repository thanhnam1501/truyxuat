<?php $__env->startSection('content'); ?>
<div class="row">

	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">						
		<div class="card mb-3">
			<div class="card-header">
				<h3><i class="fa fa-check-square-o"></i> Cập nhật thông tin sản phẩm</h3>

			</div>

			<div class="card-body">

				<form action="<?php echo e(route('product.update')); ?>" method="POST" class="form-horizontal" role="form" enctype="multipart/form-data">
					<input style="display: none" type="hidden" id="id" name="id" value="<?php echo e($data->id); ?>" >
					<div class="form-group">
						<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 col-xl-3">
							<?php if($data->image): ?>
							<img style="width: 50%;margin-left: 20%; border: solid 1px black" src="<?php echo e(asset('public/'.$data->image)); ?>" alt="">
							<?php else: ?>
							<img style="width: 50%;margin-left: 20%; border: solid 1px black" src="<?php echo e(asset('public/image/noimage.png')); ?>" alt="">
							<?php endif; ?>
						</div>
						<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-6">
							
							<label for="exampleInputEmail1">Tên sản phẩm</label>
							<input type="text" class="form-control" id="name" name="name" value="<?php echo e($data->name); ?>" placeholder="Tên sản phẩm" required>
							

							<br>	

							<label>Tên doanh nghiệp</label>
							<select class="form-control" name="company_id" id="company_id" value="<?php echo e($data->company_id); ?>">
								<?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option <?php if($data->company_id == $company->id): ?> selected <?php endif; ?> value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>

							<div class="form-group">
								<label for="exampleInputEmail1">Các bước cập nhật</label>
								<input type="number" class="form-control" id="node" name="node" value="<?php echo e($data->node); ?>" disabled>
							</div>				

							<div class="form-group">
								<label for="exampleInputEmail1">Liên kết tĩnh</label>
								<input type="text" class="form-control" id="slug" name="slug" value="<?php echo e($data->slug); ?>" >
							</div>	
							<a onclick="window.open('<?php echo e($urlSlug); ?>')"><?php echo e($urlSlug); ?></a>
							
						</div>
						<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 col-xl-3">
							<img style="margin-left: 20%" src="data:image/png;base64, <?php echo base64_encode(QrCode::format('png')
							->size(200)
							->generate($url)); ?> ">
							
						</div>
					</div> 

					
					<div class="form-group">
						<label>Mô tả ngắn sản phẩm</label>
						<textarea name="sort_content" value="<?php echo e($data->sort_content); ?>" class="form-control " id="editor1"><?php echo $data->sort_content; ?></textarea>
					</div> 
					<div class="form-group">
						<label>Mô tả</label>
						<textarea name="content" value="<?php echo e($data->content); ?>" class="form-control " id="editor2"><?php echo $data->content; ?></textarea>
					</div> 
					<?php echo e(csrf_field()); ?>

					<div class="form-group">
						<label for="exampleInputEmail1">Ảnh sản phẩm</label>
						<input type="file" id="image_update" name="image_update" >

						
					</div>
					<button type="submit" class="btn btn-primary">Cập nhật</button>
				</form>

			</div>														
		</div><!-- end card-->					
	</div>
	
	<?php for($i=0; $i <= $data->node ; $i++): ?>
	<?php $__currentLoopData = $nodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php if($i == $key): ?>
	<div  class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 x_panel" 
	style="border-color:red !important;">						
	<div class="card mb-3" >
		<div class="card-header">
			
			
			<div role="tabpanel" class="tab-pane <?php if($i==0): ?>active <?php endif; ?> fade in" id="tab_content<?php echo e($i); ?>" aria-labelledby="home-tab">
				<?php if($value->status == 1): ?>
				<a data-tooltip="tooltip" title="Đã kích hoạt" href="javascript:;" onclick="activatedNode(<?php echo e($value->id); ?>)" class="btn btn-success "> <h3><i class="fa fa-check-square-o"></i> <?php echo e($value->name); ?></h3></i></a>
				<?php else: ?>
				<a data-tooltip="tooltip" title="Đã kích hoạt" href="javascript:;" onclick="activatedNode(<?php echo e($value->id); ?>)" class="btn btn-danger "><h3><i class="fa fa-check-square-o"></i> <?php echo e($value->name); ?></h3></i></a>
				<?php endif; ?>

			</div>
		</div>
		<?php if($errors->any()): ?>
		<div class="alert alert-danger"><?php echo e(implode('', $errors->all(':message'))); ?></div>
		<?php endif; ?>
		<br>
		<div class="clearfix"></div>
		<div class="card-body" >
			<form action="<?php echo e(route('node.updateById')); ?>" method="POST" class="form-horizontal" role="form" enctype="multipart/form-data" id="formUpdate<?php echo e($i); ?>">

				<div class="form-group">
					<label>Tên bước cập nhật</label>
					<input type="text" class="form-control" id="name<?php echo e($i); ?>" name="name" value="<?php echo e($value->name); ?>" placeholder="Họ và Tên" required>
					<input type="hidden" class="form-control" id="id<?php echo e($i); ?>" name="id" value="<?php echo e($value->id); ?>" placeholder="Họ và Tên" required>
					<input name="_method" type="hidden" value="PATCH">
				</div>

				<div class="form-group">
					<label>Mô tả</label>
					<textarea name="content" value="<?php echo e($value->content); ?>" class="form-control " id="editor<?php echo e($i + 3); ?>"><?php echo e($value->content); ?></textarea>
				</div> 

				<?php echo e(csrf_field()); ?>


				<button type="submit" class="btn btn-primary">Cập nhật</button>
			</form>


		</div>
	</div>
</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endfor; ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php echo $__env->make('ckfinder::setup', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script>
 	function activatedNode(id){
 		$.ajax({
 			url: '<?php echo e(route('node.activated')); ?>',
 			type: 'POST',
 			data: {id: id},

 			success: function success(res) {
 				if (res.node_status == 0) {

 					toastr.success('Bước cập nhật đã được mở khóa thành công!');			
 					setTimeout(function(){
 						   location.reload();
 					}, 3000);
 					
 				}
 				else{
 					toastr.error('Bước cập nhật đã bị khóa!');

 					setTimeout(function(){
 						   location.reload();
 					}, 3000);
 				} 
 			},
 			error: function error(xhr, ajaxOptions, thrownError) {

 				toastr.error("Lỗi! Không thể sửa! <br>Vui lòng thử lại hoặc liên lạc với IT");
 			}

 		});
 	}
 </script>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>