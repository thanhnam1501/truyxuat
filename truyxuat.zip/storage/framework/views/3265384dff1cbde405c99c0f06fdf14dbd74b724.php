<?php $__env->startSection('content'); ?>
<div class="row">

	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">						
		<div class="card mb-3">
			<div class="card-header">
				<h3><i class="fa fa-check-square-o"></i> Cập nhật thông tin doanh nghiệp</h3>

			</div>

			<div class="card-body">

				<form method="POST" action="<?php echo e(route('company.update')); ?>">
					<input style="display: none" type="hidden" id="id" name="id" value="<?php echo e($data->id); ?>" >
					<div class="form-group">
						<label for="exampleInputEmail1">Tên doanh nghiệp</label>
						<input type="text" class="form-control" id="name" name="name" value="<?php echo e($data->name); ?>" placeholder="Tên doanh nghiệp" required>
						
					</div>
					<div class="form-group">
						<label for="exampleInputEmail1">Mã số thuế</label>
						<input type="number" class="form-control" id="tax_code" name="tax_code" value="<?php echo e($data->tax_code); ?>" placeholder="Mã số thuế" required>
						
					</div>
					
					<div class="form-group">
						<label for="exampleInputEmail1">Số điện thoại</label>
						<input type="number" class="form-control" id="mobile_phone" name="mobile_phone" value="<?php echo e($data->mobile_phone); ?>" placeholder="Số điện thoại" required>
						
					</div>
					
					<div class="form-group">
						<label for="exampleInputEmail1">Địa chỉ</label>
						<input type="text" class="form-control" id="address" value="<?php echo e($data->address); ?>" name="address" placeholder="Địa chỉ" required>
						
					</div>

					<div class="form-group">
						<label for="exampleInputEmail1">Giới hạn tài khoản</label>
						<input type="number" class="form-control" id="account_limit" name="account_limit" value="<?php echo e($data->account_limit); ?>" placeholder="Giới hạn tài khoản" required>
						
					</div>

					<div class="form-group">
						<label for="exampleInputEmail1">Giới hạn sản phẩm</label>
						<input type="number" class="form-control" id="product_limit" name="product_limit" value="<?php echo e($data->product_limit); ?>" placeholder="Giới hạn sản phẩm" required>
						
					</div>
					<div class="form-group">
						<label for="exampleInputEmail1">Giới hạn thời gian: <span style="color: red; font-size: 20px;"><?php echo e($data->time_limit); ?> Tháng từ ngày <?php echo e($data->created_at->toDateString()); ?></span></label>
					</div>

					<div class="form-group">
						<label for="exampleInputEmail1">Gian hạn thêm thời gian</label>
						<select class="form-control" name="add_time_limit" id="add_time_limit" >
							<option value="0">Gia hạn hợp đồng</option>
							<option value="3">3 Tháng</option>
							<option value="6">6 Tháng</option>
							<option value="9">9 Tháng</option>
							<option value="12">12 Tháng</option>							
						</select>
					</div>

					<div class="form-group">
						<label>Mô tả</label>
						<textarea name="content" value="<?php echo e($data->content); ?>" class="form-control " id="editor1"></textarea>
					</div> 


					  <?php echo e(csrf_field()); ?>


					<button type="submit" class="btn btn-primary">Cập nhật</button>
				</form>

			</div>														
		</div><!-- end card-->					
	</div>

	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>