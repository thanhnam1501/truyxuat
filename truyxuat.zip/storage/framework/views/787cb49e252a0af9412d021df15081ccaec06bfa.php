<?php $__env->startSection('content'); ?>
<style>

.imageProduct{
 max-width: 100%;
 margin: 5px auto;
 justify-content: center;
</style>

<div >
  <div>
    <h3 style="color: red"><?php echo e($product->name); ?></h3>
  </div>
  <div >
    <div class="x_panel">
      <div class="x_title">
        <h2><i class="fa fa-bars"></i> Thông tin sản phẩm</h2>

        <div class="clearfix"></div>
      </div>
      <div class="x_content">

        <div class="col-xs-12 col-md-6 col-sm-6">
          <!-- required for floating -->
          <!-- Nav tabs -->
          <?php if($product->image): ?>
          <img style="width: 50%;margin-left: 20%; border: solid 1px black" src="<?php echo e(asset($product->image)); ?>" alt="">
          <?php else: ?>
          <img style="width: 50%;margin-left: 20%; border: solid 1px black" src="<?php echo e(asset('image/noimage.png')); ?>" alt="">
          <?php endif; ?>
        </div>

        <div class="col-xs-12 col-md-6 col-sm-6">
          <!-- Tab panes -->
          <div class="tab-content">
            <div class="tab-pane active" id="home">
              <p>
                <?php echo $product->sort_content; ?>

              </p>
            </div>
          </div>
        </div>

        <div class="clearfix"></div>

      </div>
    </div>
  </div>
</div>


<div ">
  <div class="x_panel">
    <div class="x_title">
      <h2><i class="fa fa-bars"></i> Mô tả</h2>
      
      <div class="clearfix"></div>
    </div>
    <div class="x_content">

      <div class="col-xs-12">
        <!-- Tab panes -->
        <div class="tab-content">
         <p><?php echo $product->content; ?></p>
       </div>
     </div>

     <div class="clearfix"></div>

   </div>
 </div>
</div>

<div >
  <div class="x_panel">
    <div class="x_title">
      <h2><i class="fa fa-bars"></i> Quy trình</h2>
      
      <div class="clearfix"></div>
    </div>
    <div class="x_content">

      <div class="col-md-3 col-xs-12">
        <!-- required for floating -->
        <!-- Nav tabs -->
        <ul class="nav nav-tabs tabs-left">
          <?php for($i= 0; $i < $product->node ; $i++): ?>
          <?php $__currentLoopData = $nodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($key == $i): ?>
          <li role="presentation" class="<?php if($i==0): ?>active <?php endif; ?> col-xs-12"><a href="#tab_content<?php echo e($i); ?>" role="tab" id="profile-tab" data-toggle="tab"  aria-expanded="false"><?php echo e($value->name); ?></a>

          </li>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endfor; ?>
        </ul>
      </div>

      <div class="col-md-9 col-xs-12">
        <!-- Tab panes -->
        <div class="tab-content">
         <?php for($i= 0; $i < $product->node ; $i++): ?>
         <?php $__currentLoopData = $nodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php if($key === $i): ?>
         <div role="tabpanel" class="tab-pane <?php if($i==0): ?>active <?php endif; ?> fade in" id="tab_content<?php echo e($i); ?>" aria-labelledby="home-tab">
           <?php if($value->status == 1): ?>
           <a data-tooltip="tooltip" title="Đã kích hoạt" href="javascript:;" onclick="activatedNode(<?php echo e($value->id); ?>)" class="btn btn-success "><i class="fa fa-check"> Node đã được kích hoạt</i></a>
           <?php else: ?>
           <a data-tooltip="tooltip" title="Đã kích hoạt" href="javascript:;" onclick="activatedNode(<?php echo e($value->id); ?>)" class="btn btn-danger "><i class="fa fa-check"> Node chưa được kích hoạt</i></a>
           <?php endif; ?>
           <p><?php echo e($value->content); ?></p>
         </div>
         <?php endif; ?>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php endfor; ?>
       </div>
     </div>

     <div class="clearfix"></div>

   </div>
 </div>
</div>






<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
  $(function() {
    $('#product-list').DataTable({
      processing: false,
      serverSide: true,
      order: [],
      ajax: '<?php echo route('user.product.getList'); ?>',
      pageLength: 30,
      lengthMenu: [[30, 50, 100, 200, 500], [30, 50, 100, 200, 500]],
      columns: [
      {data: 'DT_Row_Index', name: 'DT_Row_Index', 'class':'dt-center', searchable: false},
      {data: 'name', name: 'name'},
      {data: 'updated_at', name: 'updated_at'},
      {data: 'created_at', name: 'created_at',orderable: false,},
      {data: 'action', name: 'action', searchable: false},
      ]
    });

  });

</script>
<script>    
  function deleteProduct(id){
   swal({
    title: "Bạn có chắc muốn xóa?",
    text: "Bạn sẽ không thể khôi phục dữ liệu này!",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  })
   .then((willDelete) => {
    if (willDelete) {

     $.ajax({
      url: '<?php echo e(route('user.product.delete')); ?>',
      type: 'POST',
      data: {id: id},

      success: function success(res) {

        if (!res.error) {

          toastr.error(res.message);
          $('#product-list').DataTable().ajax.reload();
        } else {

          toastr.error(res.message);
        }
      },
      error: function error(xhr, ajaxOptions, thrownError) {

        toastr.error("Lỗi! Không thể xóa! <br>Vui lòng thử lại hoặc liên lạc với IT");
      }

    });
   } 
 });
 }
</script>
<script>
  function activatedNode(id){
   $.ajax({
    url: '<?php echo e(route('user.node.activated')); ?>',
    type: 'POST',
    data: {id: id},

    success: function success(res) {

      if (res.status == true) {

        toastr.success(res.message);
        location.reload();
        setTimeout(function(){
             location.reload();
        }, 5000);
      } 
    },
    error: function error(xhr, ajaxOptions, thrownError) {

      toastr.error("Lỗi! Không thể sửa! <br>Vui lòng thử lại hoặc liên lạc với IT");
    }

  });
 }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>