<?php $__env->startSection('content'); ?>
<div>						
	<div class="card mb-3">
		<div class="card-header">
			<h3><i class="fa fa-check-square-o"></i> Thêm  bước cập nhật</h3>
			
		</div>
		<?php if($errors->any()): ?>
		<div class="alert alert-danger"><?php echo e(implode('', $errors->all(':message'))); ?></div>
		<?php endif; ?>
		<br>
		<div class="clearfix"></div>
		<div class="card-body">
			<form action="<?php echo e(route('user.node.createOne')); ?>" method="POST">
			
				<div class="form-group">
					<label></label>
				</div>
				<div class="col-md-12 col-sm-12 col-xs-12 form-group has-feedback">
					<input type="text" class="form-control has-feedback-left" id="name" name="name" placeholder="Tên bước"  required>
					<span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
				</div>

				<div class="col-md-12 col-sm-12 col-xs-12 form-group has-feedback">
					
			
					<textarea  class="form-control " id="editor1" name="content"></textarea>
					
				</div>

				<div class="col-md-12 col-sm-12 col-xs-12 form-group has-feedback">

					<select class="form-control has-feedback-left" name="product_id" id="product_i" required>
						<option value="">Chọn sản phẩm</option>
						<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
				</div>

				<div class="col-md-12 col-sm-12 col-xs-12 form-group has-feedback">

					<select class="form-control has-feedback-left" name="user_id" id="user_id" required>
						<option value="">Chọn nhân viên quản lý</option>
						<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
				</div>
			
				<?php echo e(csrf_field()); ?> 	

				<button type="submit" class="btn btn-primary">Tạo mới</button>
			</form>

		</div>
	</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>