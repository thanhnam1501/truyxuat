<?php $__env->startSection('content'); ?>
<div>
   <?php if(isset($messageError)): ?>
 <div class="alert alert-danger">
     <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
     <?php echo e($messageError); ?>

 </div>
 <?php endif; ?>
 <?php if(isset($messageSuccess)): ?>
 <div class="alert alert-success">
     <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
     <?php echo e($messageSuccess); ?>

 </div>
 <?php endif; ?>
</div>
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">						
	<div class="card mb-3">
		<div class="card-header">
			<h3><i class="fa fa-check-square-o"></i> Cập nhật quản trị viên</h3>
			
		</div>
		<?php if($errors->any()): ?>
		<div class="alert alert-danger"><?php echo e(implode('', $errors->all(':message'))); ?></div>
		<?php endif; ?>
		<br>
		<div class="clearfix"></div>
		<div class="card-body">
			<form action="<?php echo e(route('profile.update')); ?>" method="POST">

				<div class="col-md-12 col-sm-12 col-xs-12 form-group has-feedback">
					<input type="text" class="form-control has-feedback-left" id="name" name="name" value="<?php echo e($data->name); ?>" placeholder="Họ và Tên" required>
					<span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
				</div>

				<div class="col-md-12 col-sm-12 col-xs-12 form-group has-feedback">
					<input type="email" class="form-control has-feedback-left" id="email" name="email" value="<?php echo e($data->email); ?>" placeholder="Email" readonly>
					<span class="fa fa-envelope form-control-feedback left" aria-hidden="true"></span>
				</div>

				<div class="col-md-12 col-sm-12 col-xs-12 form-group has-feedback">
					<input type="phone" class="form-control has-feedback-left" id="mobile" name="mobile" value="<?php echo e($data->mobile); ?>" placeholder="Số điện thoại" required>
					<span class="fa fa-phone form-control-feedback left" aria-hidden="true"></span>
				</div>
				<div class="col-md-12 col-sm-12 col-xs-12 form-group has-feedback">
					<select class="form-control has-feedback-left" name="company_id" id="company_id" readonly>
						<?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option <?php if($data->company_id == $company->id): ?> selected <?php endif; ?> value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<span class="fa fa-university form-control-feedback left" aria-hidden="true"></span>
					
				</div>
				<?php echo e(csrf_field()); ?>


				<button type="submit" class="btn btn-primary">Cập nhật</button>
			</form>


		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>